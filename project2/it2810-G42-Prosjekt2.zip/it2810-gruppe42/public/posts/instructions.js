var waffle = [
    "Når du lager verdens beste vafler starter du med å piske egg og sukker godt sammen. Deretter rører du inn melk og" +
    " vann.",
	"Bland sammen alt det tørre og pisk det inn i væsken til du får en klumpfri røre.",
    "La røren svelle i ca 15 minutter.",
    "Tilsett smeltet smør og stek vaflene lys brune. ",
    "Server med rømme og syltetøy eller smør og brunost. "
];

var cake = [
    "Forvarm stekeovnen til 160 °C.",
    "Pisk egg og sukker til en luftig og stiv eggedosis, 6-8 minutter.",
    "Sikt mel og bakepulver over i bollen med eggedosis.",
    "Vend melet forsiktig inn i eggedosisen med en slikkepott. Bruk myke bevegelser og bland til det ikke lenger er " +
    "melklumper i røren. Husk også å se etter melklumper i bunnen av bollen.",
    "Ha bakepapir i bunnen av en springform på 24 cm i diameter. Smør formen med smør.",
    "Hell røren i formen i et sikk sakk mønster, og stryk lett frem og tilbake med slikkepotten slik at overflaten blir jevn.",
    "Sett formen på nederste rille i ovnen og stek i ca. 40 minutter, til sukkerbrødet har hevet seg godt, er gyllent og gjennomstekt.",
    "La sukkerbrødet stå i formen et par minutter før det hvelves over på rist. Legg over et rent kjøkkenhåndkle og avkjøl sukkerbrødet.",
    "Pisk kremfløte stiv sammen med melis.",
    "Skjær et lite snitt vertikalt på sukkerbrødet. Når kakebunnen fylles og lagene legges oppå hverandre vil snittet være til hjelp for å få en jevn kake.",
    "Bruk en sagkniv og del sukkerbrødet i tre lag. ",
    "Legg et av lagene på et fat og dynk det med litt melk eller eplejuice.",
    "Smør på litt bringebærsyltetøy. Ha på krem og valnøtter. Smør kremen ut i et jevnt lag og legg på et nytt sukkerbrødlag. Gjenta prosessen.",
    "Smør tilslutt krem i et jevnt lag rundt hele kaken med en kakepalett. Ha godt med krem foran palettkniven når du " +
    "gjør dette, så unngår du smuler fra kakebunnen i kremen.",
    "Kjevle ut marsipanen til en leiv, ca. 2 mm tykkelse, bruk litt mel eller melis for å hindre at marsipanen setter " +
    "seg til benkeplaten eller kjevlet. Rull marsipanen forsiktig på kjevlet og løft den over kaken.",
    "Kle kaken med marsipanen. Bruk håndflatene til å stryke forsiktig langs kanten, samtidig som du strekker lett i " +
    "marsipanen. Da får du en slett og fin kake uten folder. Bruk en tynn spiss kniv og skjær bort marsipanen rundt kanten til slutt.",
    "Smelt sjokolade i en liten skål over et vannbad, eventuelt i mikrobølgeovnen, men se til at den ikke svir seg. " +
    "Skjær jordbær i skiver. Lag et lite kremmerhus og fyll i den smeltede sjokoladen. Kaken er klar til pynting."
];

var cookies = [
    "Rist havregrynene i stekepannen til de får litt farge. Hell over på en tallerken eller lignende slik at grynene blir avkjølt.",
    "Rør sukker og smør kremaktig. Tilsett eggene, ett av gangen og rør godt. Sikt hvetemel og natron i en bolle, tilsett " +
    "havregryn og bland godt sammen. Tilsett det tørre i smørblandingen, sammen med vaniljeekstrakt/vaniljesukker og bland det hele godt sammen.",
    "Tilsett tilslutt den hakkede sjokoladen og rør forsiktig med en slikkepott eller lignende, til sjokoladen er innarbeidet i deigen.",
    "Ha deigen på et melet bakebord og trill til en pølse. Del opp i passende emner (ca 24 stk), alt etter hvor store " +
    "cookies du ønsker. Trill til kuler og legg på bakepapirkledt stekebrett med god avstand mellom hver. Trykk kulene " +
    "litt ned med en gaffel. Stekes ved ca 175 grader over- og undervarme i ca 15 minutter, til kjeksene er gyldenbrune " +
    "og faste. La de hvile litt på stekebrettet, før du avkjøler de ytterligere på en bakerist. Oppbevares i tett boks, " +
    "og er da holdbar et par uker."
];

var candy = [
    "Legg fram alt du trenger så det er klart. Mål opp ingrediensene på forhånd. Smør silikonmatten med nøytral olje/kokosfett. Bland essens og sitronsyre.",
    "Rør sammen sukker, vann og glukose i gryten og kok opp. Når massen når 125 grader, rør i den. Nå skal mest mulig " +
    "vann fordampe. Begynn å måle temperaturen. Den skal opp i 150 grader. Rør av og til. Når det nærmer seg makstemperatur, " +
    "ha i sitronsyre og essens. Vær forsiktig, det blir mye damp. Ta av varmen. Ha i konditorfarge helt til slutt, til så " +
    "sterk farge du vil ha.",
    "Hell massen ut på teflonmatten. Den er glovarm, bruk forede hansker. Elt deigen ved å dytte massen fra kantene og " +
    "inn mot midten. Den blir gradvis fastere og smidigere. Når den er fast nok, kan den dras ut til pølser.",
    "Klipp pølsene opp til passende drops.",
    "La dropsene avkjøle seg, før de legges i tett boks eller glass."
];

exports.waffle = waffle;
exports.cake = cake;
exports.cookies = cookies;
exports.candy = candy;
